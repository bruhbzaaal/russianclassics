function choose_author(answer, context) {
    addAction({
        type: "choose_author",
        answer: answer
    }, context);
}

function read_facts(context) {
    addAction({
        type: "read_facts"
    }, context);
}

function go_back(context) {
    addAction({
        type: "go_back"
    }, context);
}
